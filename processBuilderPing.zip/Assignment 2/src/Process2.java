/*	File Name: Process2.java
 * 	File Author: Robert O'Brien
 * 	Student Number: C20436696
 * 	Publish Date: 04/03/2022
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Process2 {

	public static void main(String[] args) throws IOException, InterruptedException, ExecutionException {
		ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", " ping -n 1 www.google.com"); //Creating and Outlining the Parameters of the Process
		Process p = pb.start(); //Starting the Process
		ExecutorService servicePool = Executors.newSingleThreadExecutor(); //Creating and Defining the ExecutorService, allowing it to submit multiple tasks

		processInputStream i = new processInputStream(p.getInputStream()); //Creating a new Instance of the Below Class
		Future<List<String>> future = servicePool.submit(i); //Passing through the Variable 'i' from the Below Class' constructor 
		List<String> list = future.get(); // Defining the List so it can be printed successfully
		for (String fut: list) { //Looping through and Printing the List
			System.out.println(list);
		}
	}
}
class processInputStream implements Callable{
	private InputStream input;
	public processInputStream(InputStream i) { //Constructor taking the Lines from the InputStream and turning them into Strings
		input = i;
	}
	public Object call() throws Exception {
		List<String> myList = new ArrayList<String>(); //Creating the New List to add the Strings to 
		BufferedReader br = new BufferedReader(new InputStreamReader( //Taking the Output from Process and passing it to the BufferedReader
				input));
		String line;
		while((line = br.readLine()) != null) { //Looping through the Buffered Reader and adding it to the MyList
			myList.add(line);
		}
		return myList;
	}

}

