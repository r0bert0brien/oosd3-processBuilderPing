/*	File Name: Process1.java
 * 	File Author: Robert O'Brien
 * 	Student Number: C20436696
 * 	Publish Date: 04/03/2022
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Process1 {

	public static void main(String[] args) throws IOException {
		//Creating and Outlining the parameters of the ping
		ProcessBuilder pb = new ProcessBuilder("cmd.exe", "/c", " ping -n 10 www.google.com");
		//Starting the Process
		Process p = pb.start();
		//Adding the output of the Process to the Buffered Reader
		BufferedReader br = new BufferedReader(new InputStreamReader(
				p.getInputStream()));
		System.out.println(p.getInputStream());
		String line;
		//Printing the results of the Process' ping via the Buffered Reader
		while((line = br.readLine()) != null) {
			System.out.println(line);
		}

	}

}